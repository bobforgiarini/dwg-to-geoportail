# Install and Usage

## Plain HTML

```html
<script defer src="/dist/v1.1.0/site-info-banner.iife.js"></script>

<site-info-banner
  position="bottom-right"
  size="md"
  theme="light"
  headline="Powered by BEST"
  details="Version 1.1.0"
  logo-src="https://placehold.co/96x96/111827/ffffff/png?text=BEST"
  logo-alt="BEST"
  collapse-after="30000"
></site-info-banner>
```

## ESM

```ts
import "site-info-banner";
```

The import registers `<site-info-banner>` once through `customElements.define`.

## React

```tsx
import "site-info-banner";

export function FooterBanner() {
  return (
    <site-info-banner
      position="bottom-left"
      size="md"
      theme="dark"
      headline="Copyright 2026"
      details="Website version 1.1.0"
      logo-src="https://placehold.co/96x96/ffffff/111827/png?text=B"
      logo-alt="BEST"
      collapse-after={30000}
    />
  );
}
```

For strict JSX typing, add a small local declaration like the one in `examples/react-shadcn/custom-elements.d.ts`.
