# API

## Element

```html
<site-info-banner></site-info-banner>
```

## Attributes

| Attribute | Values | Default | Description |
| --- | --- | --- | --- |
| `position` | `top-left`, `top-right`, `bottom-left`, `bottom-right` | `bottom-right` | Fixed viewport corner. |
| `size` | `sm`, `md`, `lg` | `md` | Banner scale. |
| `theme` | `light`, `dark` | `light` | Built-in color mode. |
| `collapse-after` | milliseconds | `30000` | Delay before the first session collapse. Use `0` to disable auto-collapse. |
| `logo-src` | URL | none | Image source for the logo area. If the image fails, the built-in icon remains as fallback. |
| `logo-alt` | text | empty | Alt text for `logo-src`. |
| `headline` | text | empty | Main banner text. |
| `details` | text | empty | Secondary banner text. |
| `href` | URL | none | Renders the banner as a link instead of a button. |

Invalid `position`, `size`, `theme`, or `collapse-after` values fall back to the documented defaults.

## Slots

| Slot | Purpose |
| --- | --- |
| `logo` | Replaces the logo image or default icon. |
| `headline` | Replaces the headline attribute fallback. |
| `details` | Replaces the details attribute fallback. |

## Behavior

- First load in a browser session starts expanded.
- After `collapse-after`, the banner stores `site-info-banner:collapsed=true` in `sessionStorage` and partially hides off the page edge.
- Left-side positions render the logo/image on the right side of the banner so the visible collapsed edge stays recognizable.
- Desktop hover and keyboard focus open the banner.
- Touch tap toggles the banner open and closed.
