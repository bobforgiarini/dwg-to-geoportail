# site-info-banner v1.1.0

## Summary

`site-info-banner` is a reusable Web Component for small persistent site metadata banners. Use it for copyright, powered-by, vendor attribution, or website version information.

The component has no runtime framework dependency. It registers the custom element `<site-info-banner>` and keeps its styles inside Shadow DOM.

## Files

- Browser bundle: `dist/v1.1.0/site-info-banner.iife.js`
- ESM bundle: `dist/v1.1.0/site-info-banner.es.js`
- Types: `dist/v1.1.0/index.d.ts`
- Release folder: `releases/v1.1`
- Plain HTML example: `examples/plain-html/index.html`
- React example: `examples/react-shadcn/index.html`

## Documentation

- [Install and usage](examples.md)
- [API](api.md)
- [Styling](styling.md)
- [Release notes](release-notes.md)

## Migration Notes

This is the first release. No database migrations are required.
