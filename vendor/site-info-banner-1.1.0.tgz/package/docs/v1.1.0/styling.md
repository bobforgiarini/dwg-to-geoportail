# Styling

The component keeps its default styles in Shadow DOM. Use CSS custom properties on the element to customize it per website.

```css
site-info-banner {
  --sib-bg: #ffffff;
  --sib-color: #111827;
  --sib-muted-color: #4b5563;
  --sib-border-color: rgba(17, 24, 39, 0.14);
  --sib-logo-bg: transparent;
  --sib-logo-color: #111827;
  --sib-logo-image-size: min(32px, var(--sib-logo-size));
  --sib-border-width: 1px;
  --sib-offset-block: 1rem;
  --sib-offset-inline: 1rem;
  --sib-peek: calc(
    var(--sib-logo-size) +
    var(--sib-padding-inline) +
    var(--sib-padding-inline) +
    var(--sib-border-width) +
    var(--sib-border-width)
  );
  --sib-radius: 0.5rem;
  --sib-z-index: 2147483000;
}
```

`--sib-peek` controls how much remains visible while collapsed. By default it is calculated from the logo/image width plus inline padding and border on both sides, so the logo stays fully visible with balanced spacing.

`--sib-logo-bg` defaults to `transparent`, so the logo/image uses the main banner background. Set it only if a website needs a separate logo tile.

`--sib-logo-image-size` controls the rendered logo/image size inside the logo box. The v1.1 default is `min(32px, var(--sib-logo-size))`.

## Parts

The component exposes these Shadow DOM parts for advanced styling:

- `banner`
- `logo`
- `copy`
- `headline`
- `details`

Prefer CSS variables for normal customization because they remain stable across small internal markup changes.
