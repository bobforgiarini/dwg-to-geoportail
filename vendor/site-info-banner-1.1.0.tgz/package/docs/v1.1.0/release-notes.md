# Release Notes

## v1.1.0

Logo sizing release for `site-info-banner`.

### Added

- Default logo/image content renders at `32px` when the logo box allows it.
- Added `--sib-logo-image-size` for custom logo/image sizing.
- Kept all v1.0.0 public APIs and behavior compatible.
- Dedicated release folder at `releases/v1.1`.

### Compatibility

The package targets modern browsers with Custom Elements, Shadow DOM, and ES2020 support.
