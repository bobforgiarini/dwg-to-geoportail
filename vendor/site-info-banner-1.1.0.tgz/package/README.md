# site-info-banner

`site-info-banner` is a small TypeScript Web Component for copyright, powered-by, and version banners. It is designed to work in plain HTML, React, TypeScript, and most other frontend stacks.

## Install

```bash
npm install site-info-banner
```

## Plain HTML

Use the versioned browser bundle after building or publishing.

```html
<script defer src="/dist/v1.1.0/site-info-banner.iife.js"></script>

<site-info-banner
  position="bottom-right"
  size="md"
  theme="light"
  headline="Powered by BEST"
  details="Version 1.1.0"
  logo-src="https://placehold.co/96x96/111827/ffffff/png?text=BEST"
  logo-alt="BEST"
  collapse-after="30000"
></site-info-banner>
```

## TypeScript or React

```ts
import "site-info-banner";
```

```tsx
<site-info-banner
  position="bottom-left"
  size="md"
  theme="dark"
  headline="Copyright 2026"
  details="Website version 1.1.0"
/>
```

See [docs/v1.1.0](docs/v1.1.0/index.md) for the full API, styling variables, and release notes.
