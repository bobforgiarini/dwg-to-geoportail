# Changelog

## 1.1.0 - 2026-05-13

- Increased default logo/image rendering to `32px` where the configured logo box allows it.
- Added `--sib-logo-image-size` for website-level logo/image sizing.
- Added the versioned `dist/v1.1.0` build output.
- Added the dedicated `releases/v1.1` release folder with versioned distributable files.

## 1.0.0 - 2026-05-13

- Promoted the component to the first stable v1 release.
- Added the versioned `dist/v1.0.0` build output.
- Added the dedicated `releases/v1` release folder with versioned distributable files.
- Kept the Web Component API stable for plain HTML, React, and TypeScript usage.

## 0.1.0 - 2026-05-13

- Added the initial `site-info-banner` Web Component.
- Added configurable position, size, theme, text, logo, link, and collapse timing attributes.
- Added session-based auto-collapse, hover/focus expansion, and touch tap toggling.
- Added plain HTML and React/shadcn-style examples.
- Added unit tests, browser tests, TypeScript declarations, and versioned `dist/v0.1.0` build output.
